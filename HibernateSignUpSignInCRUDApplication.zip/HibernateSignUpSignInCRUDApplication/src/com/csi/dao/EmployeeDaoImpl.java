package com.csi.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.csi.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	private static SessionFactory factory = new AnnotationConfiguration().configure().buildSessionFactory();

	@Override
	public void signUp(Employee employee) {
		// TODO Auto-generated method stub

		Session session = factory.openSession();

		Transaction transaction = session.beginTransaction();

		session.save(employee);
		transaction.commit();
	}

	@Override
	public boolean signIn(String empEmailId, String empPassword) {
		// TODO Auto-generated method stub

		boolean status = false;

		Session session = factory.openSession();

		List<Employee> empList = session.createQuery("from Employee").list();

		for (Employee emp : empList) {
			if (emp.getEmpEmailId().equals(empEmailId) && emp.getEmpPassword().equals(empPassword)) {
				status = true;
			}
		}
		return status;
	}

	@Override
	public void updateData(int empId, Employee employee) {
		// TODO Auto-generated method stub

		Session session = factory.openSession();

		Transaction transaction = session.beginTransaction();

		List<Employee> empList = session.createQuery("from Employee").list();

		for (Employee e : empList) {
			if (e.getEmpId() == empId) {
				e.setEmpName(employee.getEmpName());
				e.setEmpAddress(employee.getEmpAddress());
				e.setEmpContactNumber(employee.getEmpContactNumber());
				e.setEmpDOB(employee.getEmpDOB());
				e.setEmpEmailId(employee.getEmpEmailId());
				e.setEmpPassword(employee.getEmpPassword());

				session.update(e);
				transaction.commit();
			}
		}
	}

	@Override
	public void deleteData(int empId) {
		// TODO Auto-generated method stub
		Session session = factory.openSession();

		Transaction transaction = session.beginTransaction();

		List<Employee> empList = session.createQuery("from Employee").list();

		for (Employee e : empList) {
			if (e.getEmpId() == empId) {

				session.delete(e);
				transaction.commit();
			}
		}
	}

	@Override
	public List<Employee> getAllData() {
		// TODO Auto-generated method stub

		Session session = factory.openSession();

		List<Employee> empList = session.createQuery("from Employee").list();

		return empList;
	}

	@Override
	public Employee getDataById(int empId) {
		// TODO Auto-generated method stub

		Session session = factory.openSession();

		Employee emp = (Employee) session.get(Employee.class, empId);
		return emp;
	}

}
