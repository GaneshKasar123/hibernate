package com.csi.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.csi.model.Employee;
import com.csi.service.EmployeeService;
import com.csi.service.EmployeeServiceImpl;

@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public static final String INDEX_PAGE = "/index.jsp";

	public static final String SIGNIN_PAGE = "/signin.jsp";

	public static final String SIGNUP_PAGE = "/signup.jsp";

	public static final String EDIT_PAGE = "/edit.jsp";

	public static final String LISTEMPLOYEE_PAGE = "/listEmployee.jsp";

	EmployeeService employeeServiceImpl = new EmployeeServiceImpl();

	public EmployeeController() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String redirect = "";

		String action = request.getParameter("action");

		if (action.equals("signup")) {

			String empName = request.getParameter("empname");

			String empAddress = request.getParameter("empaddress");

			long empContactNumber = Long.valueOf(request.getParameter("empcontactnumber"));

			Date empDOB = null;

			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

			try {
				empDOB = sdf.parse(request.getParameter("empdob"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String empEmailId = request.getParameter("empemailid");

			String empPassword = request.getParameter("emppassword");

			Employee employee = new Employee();

			employee.setEmpName(empName);
			employee.setEmpAddress(empAddress);
			employee.setEmpContactNumber(empContactNumber);
			employee.setEmpDOB(empDOB);
			employee.setEmpEmailId(empEmailId);
			employee.setEmpPassword(empPassword);

			employeeServiceImpl.signUp(employee);

			System.out.println("Signup Successfully");

			redirect = SIGNIN_PAGE;

		} else if (action.equals("signin")) {

			String empEmailId = request.getParameter("empemailid");

			String empPassword = request.getParameter("emppassword");
			if (employeeServiceImpl.signIn(empEmailId, empPassword)) {
				redirect = LISTEMPLOYEE_PAGE;
			} else {
				redirect = SIGNIN_PAGE;
			}

		} else if (action.equals("editform")) {
			redirect = EDIT_PAGE;
		} else if (action.equals("edit")) {

			int empId = Integer.parseInt(request.getParameter("empid"));
			String empName = request.getParameter("empname");

			String empAddress = request.getParameter("empaddress");

			long empContactNumber = Long.valueOf(request.getParameter("empcontactnumber"));

			Date empDOB = null;

			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

			try {
				empDOB = sdf.parse(request.getParameter("empdob"));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String empEmailId = request.getParameter("empemailid");

			String empPassword = request.getParameter("emppassword");

			Employee employee = new Employee();

			employee.setEmpName(empName);
			employee.setEmpAddress(empAddress);
			employee.setEmpContactNumber(empContactNumber);
			employee.setEmpDOB(empDOB);
			employee.setEmpEmailId(empEmailId);
			employee.setEmpPassword(empPassword);

			employeeServiceImpl.updateData(empId, employee);

			System.out.println("Data updated successfully");

			redirect = LISTEMPLOYEE_PAGE;

		} else if (action.equals("show")) {

			redirect = LISTEMPLOYEE_PAGE;
		} else if (action.equals("delete")) {
			int empId = Integer.parseInt(request.getParameter("empid"));

			employeeServiceImpl.deleteData(empId);

			System.out.println("Data deleted successfully");

			redirect = LISTEMPLOYEE_PAGE;
		}

		RequestDispatcher rd = request.getRequestDispatcher(redirect);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
